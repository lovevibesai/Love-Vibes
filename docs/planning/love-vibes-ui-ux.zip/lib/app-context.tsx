"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type AppMode = "dating" | "friendship"
export type AppScreen = "welcome" | "phone" | "mode" | "profile-setup" | "video" | "location" | "feed" | "matches" | "chat" | "profile" | "settings" | "filters" | "credits" | "expanded-profile" | "location-settings" | "visibility-settings"

interface User {
  id: string
  name: string
  age: number
  bio: string
  photoUrl: string
  videoUrl?: string
  mode: AppMode
  trustScore: number
  isVerified: boolean
  credits: number
  distance?: string
  location?: string
  isOnboarded?: boolean
  hasVideoIntro?: boolean
}

interface Match {
  id: string
  user: User
  lastMessage?: string
  unread: boolean
  timestamp: Date
}

interface AppContextType {
  currentScreen: AppScreen
  setCurrentScreen: (screen: AppScreen) => void
  mode: AppMode
  setMode: (mode: AppMode) => void
  isOnboarded: boolean
  setIsOnboarded: (value: boolean) => void
  currentUser: User | null
  setCurrentUser: (user: User | null) => void
  matches: Match[]
  setMatches: (matches: Match[]) => void
  showMatchModal: boolean
  setShowMatchModal: (show: boolean) => void
  matchedUser: User | null
  setMatchedUser: (user: User | null) => void
  user: User
  updateUser: (updates: Partial<User>) => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

// Mock data for demo
const mockUsers: User[] = [
  {
    id: "1",
    name: "Emma",
    age: 28,
    bio: "Coffee enthusiast, book lover, and sunset chaser. Looking for someone to share adventures with.",
    photoUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&q=80",
    mode: "dating",
    trustScore: 85,
    isVerified: true,
    credits: 100,
    distance: "2 miles away",
    hasVideoIntro: true,
  },
  {
    id: "2",
    name: "Sophie",
    age: 26,
    bio: "Yoga instructor by day, foodie by night. Let's explore new restaurants together!",
    photoUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&q=80",
    mode: "dating",
    trustScore: 92,
    isVerified: true,
    credits: 150,
    distance: "5 miles away",
    hasVideoIntro: true,
  },
  {
    id: "3",
    name: "Olivia",
    age: 30,
    bio: "Art curator with a passion for travel. Always planning my next adventure.",
    photoUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&q=80",
    mode: "dating",
    trustScore: 78,
    isVerified: false,
    credits: 75,
    distance: "1 mile away",
    hasVideoIntro: false,
  },
  {
    id: "4",
    name: "Maya",
    age: 25,
    bio: "Music teacher who loves hiking and spontaneous road trips. Looking for genuine connections.",
    photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&q=80",
    mode: "friendship",
    trustScore: 88,
    isVerified: true,
    credits: 200,
    distance: "3 miles away",
    hasVideoIntro: true,
  },
]

const defaultUser: User = {
  id: "self",
  name: "You",
  age: 25,
  bio: "Add a bio to tell others about yourself",
  photoUrl: "",
  mode: "dating",
  trustScore: 65,
  isVerified: false,
  credits: 50,
  location: "San Francisco, CA",
  hasVideoIntro: false,
}

const mockMatches: Match[] = [
  {
    id: "m1",
    user: mockUsers[0],
    lastMessage: "Hey! How was your weekend?",
    unread: true,
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
  },
  {
    id: "m2",
    user: mockUsers[1],
    lastMessage: "That restaurant was amazing!",
    unread: false,
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
  },
]

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>("welcome")
  const [mode, setMode] = useState<AppMode>("dating")
  const [isOnboarded, setIsOnboarded] = useState(false)
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [matches, setMatches] = useState<Match[]>(mockMatches)
  const [showMatchModal, setShowMatchModal] = useState(false)
  const [matchedUser, setMatchedUser] = useState<User | null>(null)
  const [user, setUser] = useState<User>(defaultUser)

  const updateUser = (updates: Partial<User>) => {
    setUser(prev => ({ ...prev, ...updates }))
  }

  return (
    <AppContext.Provider
      value={{
        currentScreen,
        setCurrentScreen,
        mode,
        setMode,
        isOnboarded,
        setIsOnboarded,
        currentUser,
        setCurrentUser,
        matches,
        setMatches,
        showMatchModal,
        setShowMatchModal,
        matchedUser,
        setMatchedUser,
        user,
        updateUser,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp must be used within an AppProvider")
  }
  return context
}

export { mockUsers, mockMatches }
export type { User, Match }
