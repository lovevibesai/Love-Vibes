"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { 
  X, 
  Flag,
  UserX,
  VolumeX,
  AlertTriangle
} from "lucide-react"

interface ChatMenuProps {
  userName: string
  onClose: () => void
  onUnmatch: () => void
  onReport: () => void
  onMute: () => void
}

export function ChatMenu({ userName, onClose, onUnmatch, onReport, onMute }: ChatMenuProps) {
  const [showReportModal, setShowReportModal] = useState(false)
  const [showUnmatchModal, setShowUnmatchModal] = useState(false)
  const [selectedReason, setSelectedReason] = useState<string | null>(null)

  const reportReasons = [
    "Inappropriate messages",
    "Fake profile",
    "Harassment",
    "Spam or scam",
    "Other"
  ]

  if (showReportModal) {
    return (
      <div className="fixed inset-0 bg-foreground/60 backdrop-blur-sm flex items-end z-50">
        <div className="w-full bg-card rounded-t-3xl p-5 animate-in slide-in-from-bottom duration-300">
          <div className="w-12 h-1 bg-muted rounded-full mx-auto mb-4" />
          
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">Report {userName}</h2>
            <button
              onClick={() => setShowReportModal(false)}
              className="w-8 h-8 rounded-full bg-muted flex items-center justify-center"
              aria-label="Close"
            >
              <X className="w-4 h-4 text-foreground" />
            </button>
          </div>

          <p className="text-sm text-muted-foreground mb-4">
            Help us understand what happened. Your report is anonymous.
          </p>

          <div className="space-y-2 mb-6">
            {reportReasons.map((reason) => (
              <button
                key={reason}
                onClick={() => setSelectedReason(reason)}
                className={`w-full p-4 rounded-xl border text-left transition-all ${
                  selectedReason === reason 
                    ? "border-primary bg-primary/5" 
                    : "border-border bg-card"
                }`}
              >
                <span className="font-medium text-foreground">{reason}</span>
              </button>
            ))}
          </div>

          <div className="space-y-3">
            <Button
              className="w-full h-12 bg-destructive hover:bg-destructive/90 text-destructive-foreground"
              disabled={!selectedReason}
              onClick={() => {
                onReport()
                onClose()
              }}
            >
              Submit Report
            </Button>
            <Button
              variant="outline"
              className="w-full h-12 bg-transparent"
              onClick={() => setShowReportModal(false)}
            >
              Cancel
            </Button>
          </div>
        </div>
      </div>
    )
  }

  if (showUnmatchModal) {
    return (
      <div className="fixed inset-0 bg-foreground/60 backdrop-blur-sm flex items-end z-50">
        <div className="w-full bg-card rounded-t-3xl p-5 animate-in slide-in-from-bottom duration-300">
          <div className="w-12 h-1 bg-muted rounded-full mx-auto mb-4" />
          
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-destructive" />
            </div>
            <h2 className="text-lg font-semibold text-foreground mb-2">Unmatch with {userName}?</h2>
            <p className="text-sm text-muted-foreground">
              This will remove your match and delete all messages. This cannot be undone.
            </p>
          </div>

          <div className="space-y-3 safe-bottom">
            <Button
              className="w-full h-12 bg-destructive hover:bg-destructive/90 text-destructive-foreground"
              onClick={() => {
                onUnmatch()
                onClose()
              }}
            >
              Yes, Unmatch
            </Button>
            <Button
              variant="outline"
              className="w-full h-12 bg-transparent"
              onClick={() => setShowUnmatchModal(false)}
            >
              Cancel
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-foreground/60 backdrop-blur-sm flex items-end z-50" onClick={onClose}>
      <div 
        className="w-full bg-card rounded-t-3xl p-5 animate-in slide-in-from-bottom duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-12 h-1 bg-muted rounded-full mx-auto mb-4" />
        
        <div className="space-y-2">
          <button
            onClick={() => {
              onMute()
              onClose()
            }}
            className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-muted transition-colors"
          >
            <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
              <VolumeX className="w-5 h-5 text-foreground" />
            </div>
            <div className="text-left">
              <p className="font-medium text-foreground">Mute Notifications</p>
              <p className="text-sm text-muted-foreground">Stop receiving notifications from this chat</p>
            </div>
          </button>

          <button
            onClick={() => setShowReportModal(true)}
            className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-muted transition-colors"
          >
            <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center">
              <Flag className="w-5 h-5 text-gold" />
            </div>
            <div className="text-left">
              <p className="font-medium text-foreground">Report</p>
              <p className="text-sm text-muted-foreground">Report inappropriate behavior</p>
            </div>
          </button>

          <button
            onClick={() => setShowUnmatchModal(true)}
            className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-destructive/5 transition-colors"
          >
            <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center">
              <UserX className="w-5 h-5 text-destructive" />
            </div>
            <div className="text-left">
              <p className="font-medium text-destructive">Unmatch</p>
              <p className="text-sm text-muted-foreground">Remove this match and delete messages</p>
            </div>
          </button>
        </div>

        <div className="mt-4 safe-bottom">
          <Button
            variant="outline"
            className="w-full h-12 bg-transparent"
            onClick={onClose}
          >
            Cancel
          </Button>
        </div>
      </div>
    </div>
  )
}
