"use client"

import { useState } from "react"
import { useApp } from "@/lib/app-context"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { 
  ChevronLeft, 
  MapPin, 
  Eye, 
  Bell, 
  Shield, 
  User, 
  LogOut, 
  Trash2, 
  ChevronRight,
  Lock,
  FileText,
  HelpCircle
} from "lucide-react"

export function SettingsScreen() {
  const { setCurrentScreen, user, updateUser } = useApp()
  const [notifications, setNotifications] = useState({
    matches: true,
    messages: true,
    gifts: true,
    marketing: false,
  })
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  const handleLogout = () => {
    updateUser({ isOnboarded: false })
    setCurrentScreen("welcome")
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <header className="flex items-center gap-3 px-4 py-3 border-b border-border bg-card">
        <button 
          onClick={() => setCurrentScreen("profile")}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-colors"
          aria-label="Go back"
        >
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h1 className="text-lg font-semibold text-foreground">Settings</h1>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* Location Section */}
        <section className="p-4 border-b border-border">
          <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">Location</h2>
          <button 
            className="w-full flex items-center justify-between p-4 bg-card rounded-xl shadow-card"
            onClick={() => setCurrentScreen("location-settings")}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-primary" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground">{user.location || "San Francisco, CA"}</p>
                <p className="text-sm text-muted-foreground">Tap to update</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </button>
        </section>

        {/* Visibility Section */}
        <section className="p-4 border-b border-border">
          <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">Visibility</h2>
          <div className="bg-card rounded-xl shadow-card overflow-hidden">
            <button 
              className="w-full flex items-center justify-between p-4 border-b border-border"
              onClick={() => setCurrentScreen("visibility-settings")}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-secondary" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-foreground">Show me to</p>
                  <p className="text-sm text-muted-foreground">Everyone</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                  <Lock className="w-5 h-5 text-muted-foreground" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-foreground">Incognito Mode</p>
                  <p className="text-sm text-muted-foreground">Browse without being seen</p>
                </div>
              </div>
              <Switch />
            </div>
          </div>
        </section>

        {/* Notifications Section */}
        <section className="p-4 border-b border-border">
          <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">Notifications</h2>
          <div className="bg-card rounded-xl shadow-card overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-primary" />
                <span className="font-medium text-foreground">New Matches</span>
              </div>
              <Switch 
                checked={notifications.matches}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, matches: checked }))}
              />
            </div>
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-primary" />
                <span className="font-medium text-foreground">Messages</span>
              </div>
              <Switch 
                checked={notifications.messages}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, messages: checked }))}
              />
            </div>
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-secondary" />
                <span className="font-medium text-foreground">Gifts Received</span>
              </div>
              <Switch 
                checked={notifications.gifts}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, gifts: checked }))}
              />
            </div>
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-muted-foreground" />
                <span className="font-medium text-foreground">Updates & Tips</span>
              </div>
              <Switch 
                checked={notifications.marketing}
                onCheckedChange={(checked) => setNotifications(prev => ({ ...prev, marketing: checked }))}
              />
            </div>
          </div>
        </section>

        {/* Privacy & Safety */}
        <section className="p-4 border-b border-border">
          <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">Privacy & Safety</h2>
          <div className="bg-card rounded-xl shadow-card overflow-hidden">
            <button className="w-full flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-[#4A7C59]" />
                <span className="font-medium text-foreground">Blocked Users</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-muted-foreground" />
                <span className="font-medium text-foreground">Privacy Policy</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-muted-foreground" />
                <span className="font-medium text-foreground">Terms of Service</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>
        </section>

        {/* Support */}
        <section className="p-4 border-b border-border">
          <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">Support</h2>
          <div className="bg-card rounded-xl shadow-card overflow-hidden">
            <button className="w-full flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <HelpCircle className="w-5 h-5 text-primary" />
                <span className="font-medium text-foreground">Help Center</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>
        </section>

        {/* Account Actions */}
        <section className="p-4 pb-8">
          <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">Account</h2>
          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full h-12 justify-start gap-3 border-border bg-transparent"
              onClick={handleLogout}
            >
              <LogOut className="w-5 h-5 text-muted-foreground" />
              <span className="text-foreground">Log Out</span>
            </Button>
            <Button
              variant="outline"
              className="w-full h-12 justify-start gap-3 border-destructive text-destructive hover:bg-destructive/10 bg-transparent"
              onClick={() => setShowDeleteConfirm(true)}
            >
              <Trash2 className="w-5 h-5" />
              <span>Delete Account</span>
            </Button>
          </div>
        </section>

        {/* App Version */}
        <div className="text-center pb-8">
          <p className="text-sm text-muted-foreground">Love Vibes v1.0.0</p>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-foreground/60 backdrop-blur-sm flex items-end z-50">
          <div className="w-full bg-card rounded-t-3xl p-6 animate-in slide-in-from-bottom duration-300">
            <div className="w-12 h-1 bg-muted rounded-full mx-auto mb-6" />
            <div className="text-center mb-6">
              <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8 text-destructive" />
              </div>
              <h2 className="text-xl font-semibold text-foreground mb-2">Delete Account?</h2>
              <p className="text-muted-foreground">
                This will permanently delete your profile, matches, and messages. This action cannot be undone.
              </p>
            </div>
            <div className="space-y-3">
              <Button 
                className="w-full h-12 bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                onClick={handleLogout}
              >
                Yes, Delete My Account
              </Button>
              <Button 
                variant="outline" 
                className="w-full h-12 bg-transparent"
                onClick={() => setShowDeleteConfirm(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
