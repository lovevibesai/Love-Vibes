"use client"

import { useState } from "react"
import { useApp, type Profile } from "@/lib/app-context"
import { Button } from "@/components/ui/button"
import { TrustScore } from "../trust-score"
import { ModeBadge } from "../mode-badge"
import { 
  X, 
  Heart, 
  Play, 
  Pause,
  MapPin, 
  ChevronDown,
  Shield,
  CheckCircle,
  Volume2,
  VolumeX
} from "lucide-react"

interface ExpandedProfileProps {
  profile: Profile
  onClose: () => void
  onLike: () => void
  onPass: () => void
}

export function ExpandedProfile({ profile, onClose, onLike, onPass }: ExpandedProfileProps) {
  const { user } = useApp()
  const [activePhoto, setActivePhoto] = useState(0)
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(true)

  const photos = [
    profile.photoUrl,
    `https://picsum.photos/seed/${profile.id}2/800/1000`,
    `https://picsum.photos/seed/${profile.id}3/800/1000`,
  ]

  const interests = ["Travel", "Photography", "Cooking", "Hiking", "Art", "Music"]

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col">
      {/* Photo/Video Section */}
      <div className="relative h-[55%] bg-foreground/5">
        {/* Photo Indicator Dots */}
        <div className="absolute top-4 left-0 right-0 z-20 flex justify-center gap-1.5 px-4">
          {photos.map((_, index) => (
            <button
              key={index}
              onClick={() => setActivePhoto(index)}
              className={`h-1 rounded-full transition-all ${
                index === activePhoto 
                  ? "bg-card w-6" 
                  : "bg-card/50 w-4"
              }`}
              aria-label={`View photo ${index + 1}`}
            />
          ))}
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-foreground/30 backdrop-blur-md flex items-center justify-center"
          aria-label="Close profile"
        >
          <ChevronDown className="w-6 h-6 text-card" />
        </button>

        {/* Video Player Overlay */}
        {isVideoPlaying ? (
          <div className="absolute inset-0 bg-foreground z-10 flex items-center justify-center">
            {/* Simulated video player */}
            <div className="relative w-full h-full">
              <img
                src={profile.photoUrl || "/placeholder.svg"}
                alt={`${profile.name}'s video intro`}
                className="w-full h-full object-cover"
              />
              {/* Video Controls Overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button
                  onClick={() => setIsVideoPlaying(false)}
                  className="w-16 h-16 rounded-full bg-card/20 backdrop-blur-md flex items-center justify-center"
                >
                  <Pause className="w-8 h-8 text-card" />
                </button>
              </div>
              {/* Mute Toggle */}
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="absolute bottom-4 right-4 w-10 h-10 rounded-full bg-foreground/30 backdrop-blur-md flex items-center justify-center"
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5 text-card" />
                ) : (
                  <Volume2 className="w-5 h-5 text-card" />
                )}
              </button>
              {/* Progress Bar */}
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-card/30">
                <div className="h-full bg-primary w-1/3 animate-pulse" />
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Photo */}
            <img
              src={photos[activePhoto] || "/placeholder.svg"}
              alt={`${profile.name}'s photo ${activePhoto + 1}`}
              className="w-full h-full object-cover"
            />
            
            {/* Gradient Overlay */}
            <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-foreground/60 to-transparent" />
            
            {/* Video Play Button */}
            {profile.hasVideoIntro && (
              <button
                onClick={() => setIsVideoPlaying(true)}
                className="absolute bottom-20 right-4 flex items-center gap-2 px-4 py-2 rounded-full bg-card/20 backdrop-blur-md border border-card/30"
              >
                <Play className="w-4 h-4 text-card fill-card" />
                <span className="text-sm font-medium text-card">Watch Intro</span>
              </button>
            )}
          </>
        )}

        {/* Mode Badge */}
        <div className="absolute top-4 left-4 z-20">
          <ModeBadge mode={profile.mode} size="lg" />
        </div>
      </div>

      {/* Profile Info */}
      <div className="flex-1 overflow-y-auto bg-background">
        <div className="p-5">
          {/* Name, Age, Verified */}
          <div className="flex items-center gap-2 mb-2">
            <h1 className="text-2xl font-bold text-foreground">
              {profile.name}, {profile.age}
            </h1>
            {profile.isVerified && (
              <div className="flex items-center gap-1 text-gold">
                <CheckCircle className="w-5 h-5 fill-gold text-card" />
              </div>
            )}
          </div>

          {/* Location & Distance */}
          <div className="flex items-center gap-1 text-muted-foreground mb-4">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{profile.distance} miles away</span>
          </div>

          {/* Trust Score Card */}
          <div className="flex items-center gap-4 p-4 bg-card rounded-xl shadow-card mb-5">
            <TrustScore score={profile.trustScore} size="lg" />
            <div>
              <div className="flex items-center gap-1">
                <Shield className="w-4 h-4 text-trust-high" />
                <span className="font-semibold text-foreground">Trust Score</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {profile.trustScore >= 80 
                  ? "Highly trusted member" 
                  : profile.trustScore >= 50 
                    ? "Building trust" 
                    : "New member"}
              </p>
            </div>
          </div>

          {/* Bio */}
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-2">About</h2>
            <p className="text-foreground leading-relaxed">{profile.bio}</p>
          </div>

          {/* Interests */}
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Interests</h2>
            <div className="flex flex-wrap gap-2">
              {interests.map((interest) => (
                <span 
                  key={interest}
                  className="px-3 py-1.5 bg-muted rounded-full text-sm font-medium text-foreground"
                >
                  {interest}
                </span>
              ))}
            </div>
          </div>

          {/* Mode Info */}
          <div className="p-4 bg-card rounded-xl shadow-card mb-5">
            <div className="flex items-center gap-2">
              <ModeBadge mode={profile.mode} />
              <span className="font-medium text-foreground">
                {profile.mode === "dating" ? "Looking for Love" : "Seeking Friendship"}
              </span>
            </div>
            {user.mode !== profile.mode && (
              <p className="text-sm text-muted-foreground mt-2">
                Note: You're currently in {user.mode === "dating" ? "Dating" : "Friendship"} mode
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Action Bar */}
      <div className="px-5 py-4 bg-card border-t border-border safe-bottom">
        <div className="flex items-center justify-center gap-6">
          <Button
            variant="outline"
            size="lg"
            className="w-16 h-16 rounded-full border-2 border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground transition-all bg-transparent"
            onClick={() => {
              onPass()
              onClose()
            }}
            aria-label="Pass"
          >
            <X className="w-7 h-7" />
          </Button>
          <Button
            size="lg"
            className="w-20 h-20 rounded-full bg-primary hover:bg-primary-hover text-primary-foreground transition-all shadow-modal"
            onClick={() => {
              onLike()
              onClose()
            }}
            aria-label="Like"
          >
            <Heart className="w-9 h-9 fill-current" />
          </Button>
        </div>
      </div>
    </div>
  )
}
