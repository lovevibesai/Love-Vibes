"use client"

import { useState } from "react"
import { useApp } from "@/lib/app-context"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { 
  ChevronLeft, 
  RotateCcw,
  MapPin,
  Users,
  Shield,
  Video
} from "lucide-react"

interface Filters {
  distance: number
  ageRange: [number, number]
  showVerifiedOnly: boolean
  showWithVideoOnly: boolean
  minTrustScore: number
}

export function FiltersScreen() {
  const { setCurrentScreen } = useApp()
  const [filters, setFilters] = useState<Filters>({
    distance: 25,
    ageRange: [21, 45],
    showVerifiedOnly: false,
    showWithVideoOnly: false,
    minTrustScore: 0,
  })

  const resetFilters = () => {
    setFilters({
      distance: 25,
      ageRange: [21, 45],
      showVerifiedOnly: false,
      showWithVideoOnly: false,
      minTrustScore: 0,
    })
  }

  const applyFilters = () => {
    // In a real app, this would save to state/API
    setCurrentScreen("feed")
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-border bg-card">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setCurrentScreen("feed")}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-colors"
            aria-label="Go back"
          >
            <ChevronLeft className="w-6 h-6 text-foreground" />
          </button>
          <h1 className="text-lg font-semibold text-foreground">Filters</h1>
        </div>
        <button 
          onClick={resetFilters}
          className="flex items-center gap-1 text-primary text-sm font-medium"
        >
          <RotateCcw className="w-4 h-4" />
          Reset
        </button>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Distance */}
        <section className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <MapPin className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Maximum Distance</h2>
              <p className="text-sm text-muted-foreground">{filters.distance} miles</p>
            </div>
          </div>
          <div className="px-2">
            <Slider
              value={[filters.distance]}
              onValueChange={([value]) => setFilters(prev => ({ ...prev, distance: value }))}
              max={100}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between mt-2 text-xs text-muted-foreground">
              <span>1 mi</span>
              <span>100 mi</span>
            </div>
          </div>
        </section>

        {/* Age Range */}
        <section className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Age Range</h2>
              <p className="text-sm text-muted-foreground">{filters.ageRange[0]} - {filters.ageRange[1]} years</p>
            </div>
          </div>
          <div className="px-2">
            <Slider
              value={filters.ageRange}
              onValueChange={(value) => setFilters(prev => ({ ...prev, ageRange: value as [number, number] }))}
              max={99}
              min={18}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between mt-2 text-xs text-muted-foreground">
              <span>18</span>
              <span>99</span>
            </div>
          </div>
        </section>

        {/* Minimum Trust Score */}
        <section className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#4A7C59]/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-[#4A7C59]" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Minimum Trust Score</h2>
              <p className="text-sm text-muted-foreground">
                {filters.minTrustScore === 0 ? "Show all" : `${filters.minTrustScore}+`}
              </p>
            </div>
          </div>
          <div className="px-2">
            <Slider
              value={[filters.minTrustScore]}
              onValueChange={([value]) => setFilters(prev => ({ ...prev, minTrustScore: value }))}
              max={100}
              min={0}
              step={10}
              className="w-full"
            />
            <div className="flex justify-between mt-2 text-xs text-muted-foreground">
              <span>All</span>
              <span>100</span>
            </div>
          </div>
        </section>

        {/* Toggle Options */}
        <section className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-card rounded-xl shadow-card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 flex items-center justify-center">
                <Shield className="w-5 h-5 text-[#D4AF37]" />
              </div>
              <div>
                <p className="font-medium text-foreground">Verified Profiles Only</p>
                <p className="text-sm text-muted-foreground">Show only verified users</p>
              </div>
            </div>
            <Switch
              checked={filters.showVerifiedOnly}
              onCheckedChange={(checked) => setFilters(prev => ({ ...prev, showVerifiedOnly: checked }))}
            />
          </div>

          <div className="flex items-center justify-between p-4 bg-card rounded-xl shadow-card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Video className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Has Video Intro</p>
                <p className="text-sm text-muted-foreground">Show only profiles with videos</p>
              </div>
            </div>
            <Switch
              checked={filters.showWithVideoOnly}
              onCheckedChange={(checked) => setFilters(prev => ({ ...prev, showWithVideoOnly: checked }))}
            />
          </div>
        </section>
      </div>

      {/* Apply Button */}
      <div className="p-4 border-t border-border bg-card safe-bottom">
        <Button 
          className="w-full h-12 bg-primary hover:bg-primary-hover text-primary-foreground font-semibold text-base"
          onClick={applyFilters}
        >
          Apply Filters
        </Button>
      </div>
    </div>
  )
}
