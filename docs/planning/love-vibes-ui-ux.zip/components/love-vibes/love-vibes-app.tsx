"use client"

import { useApp } from "@/lib/app-context"
import { BottomNav } from "./bottom-nav"
import { DevToolbar } from "./dev-toolbar"
import { WelcomeScreen } from "./onboarding/welcome-screen"
import { PhoneScreen } from "./onboarding/phone-screen"
import { ModeScreen } from "./onboarding/mode-screen"
import { ProfileSetupScreen } from "./onboarding/profile-setup-screen"
import { VideoScreen } from "./onboarding/video-screen"
import { LocationScreen } from "./onboarding/location-screen"
import { FeedScreen } from "./feed/feed-screen"
import { FiltersScreen } from "./feed/filters-screen"
import { MatchesScreen } from "./matches/matches-screen"
import { ChatScreen } from "./chat/chat-screen"
import { ProfileScreen } from "./profile/profile-screen"
import { SettingsScreen } from "./settings/settings-screen"
import { CreditsStore } from "./credits/credits-store"

export function LoveVibesApp() {
  const { currentScreen, isOnboarded } = useApp()

  // Onboarding screens
  if (!isOnboarded) {
    return (
      <div className="h-screen max-w-md mx-auto">
        {currentScreen === "welcome" && <WelcomeScreen />}
        {currentScreen === "phone" && <PhoneScreen />}
        {currentScreen === "mode" && <ModeScreen />}
        {currentScreen === "profile-setup" && <ProfileSetupScreen />}
        {currentScreen === "video" && <VideoScreen />}
        {currentScreen === "location" && <LocationScreen />}
        {!["welcome", "phone", "mode", "profile-setup", "video", "location"].includes(currentScreen) && <WelcomeScreen />}
        <DevToolbar />
      </div>
    )
  }

  // Main app screens with bottom navigation
  const showBottomNav = ["feed", "matches", "profile"].includes(currentScreen)

  return (
    <div className="h-screen flex flex-col max-w-md mx-auto">
      <main className="flex-1 overflow-hidden">
        {currentScreen === "feed" && <FeedScreen />}
        {currentScreen === "filters" && <FiltersScreen />}
        {currentScreen === "matches" && <MatchesScreen />}
        {currentScreen === "chat" && <ChatScreen />}
        {currentScreen === "profile" && <ProfileScreen />}
        {currentScreen === "settings" && <SettingsScreen />}
        {currentScreen === "credits" && <CreditsStore />}
      </main>
      {showBottomNav && <BottomNav />}
      <DevToolbar />
    </div>
  )
}
