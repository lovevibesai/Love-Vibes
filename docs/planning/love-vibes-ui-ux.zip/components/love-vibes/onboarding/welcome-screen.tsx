"use client"

import Image from "next/image"
import { useApp } from "@/lib/app-context"
import { Button } from "@/components/ui/button"

export function WelcomeScreen() {
  const { setCurrentScreen } = useApp()

  return (
    <div className="min-h-screen gradient-love flex flex-col items-center justify-center px-6 text-white relative overflow-hidden">
      {/* Decorative Elements - Subtle glows */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-64 h-64 rounded-full bg-white/5 blur-3xl" />
      <div className="absolute bottom-40 left-8 w-32 h-32 rounded-full bg-rose-gold/10 blur-2xl" />
      <div className="absolute top-1/3 right-4 w-24 h-24 rounded-full bg-white/5 blur-xl" />

      {/* Logo */}
      <div className="relative mb-8">
        <Image
          src="/logo.png"
          alt="Love Vibes"
          width={140}
          height={140}
          priority
        />
      </div>

      {/* Main Content */}
      <div className="text-center mb-12">
        <h1 className="font-serif text-[42px] font-medium mb-4 text-balance leading-tight">
          Find Your Vibe
        </h1>
        <p className="text-white/90 text-lg font-light tracking-wide">
          Meaningful connections, your way
        </p>
      </div>

      {/* CTA */}
      <div className="w-full max-w-sm mt-auto mb-12 relative z-10">
        <Button
          onClick={() => setCurrentScreen("phone")}
          className="w-full h-14 bg-white text-[#5A2A4A] hover:bg-white/95 font-semibold text-base rounded-2xl shadow-modal transition-transform active:scale-[0.98]"
        >
          Get Started
        </Button>
        
        <p className="text-center text-white/70 text-xs mt-6 px-4 leading-relaxed">
          By continuing, you agree to our{" "}
          <span className="underline cursor-pointer hover:text-white transition-colors">Terms of Service</span> and{" "}
          <span className="underline cursor-pointer hover:text-white transition-colors">Privacy Policy</span>
        </p>
      </div>
    </div>
  )
}
