"use client"

import { useState } from "react"
import { useApp } from "@/lib/app-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Camera, Plus } from "lucide-react"
import { cn } from "@/lib/utils"

export function ProfileSetupScreen() {
  const { setCurrentScreen, setCurrentUser, mode } = useApp()
  const [name, setName] = useState("")
  const [age, setAge] = useState("")
  const [bio, setBio] = useState("")
  const [photoPreview, setPhotoPreview] = useState<string | null>(null)

  const isValid = name.length >= 2 && age.length > 0

  const handlePhotoChange = () => {
    // Mock photo selection for demo
    setPhotoPreview("https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80")
  }

  const handleContinue = () => {
    if (isValid) {
      setCurrentUser({
        id: "current",
        name,
        age: parseInt(age),
        bio,
        photoUrl: photoPreview || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80",
        mode,
        trustScore: 50,
        isVerified: false,
        credits: 100,
      })
      setCurrentScreen("video")
    }
  }

  const handleSkip = () => {
    setCurrentUser({
      id: "current",
      name: name || "User",
      age: parseInt(age) || 25,
      bio: "",
      photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80",
      mode,
      trustScore: 30,
      isVerified: false,
      credits: 50,
    })
    setCurrentScreen("video")
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="flex items-center justify-between px-4 h-14">
        <button
          onClick={() => setCurrentScreen("mode")}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-colors"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
        <button
          onClick={handleSkip}
          className="text-muted-foreground text-sm font-medium hover:text-foreground transition-colors"
        >
          Skip
        </button>
      </header>

      {/* Progress */}
      <div className="px-6 mb-6">
        <div className="flex gap-1.5">
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className={cn(
                "h-1 rounded-full flex-1 transition-colors",
                i <= 3 ? "bg-primary" : "bg-muted"
              )}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 overflow-y-auto">
        <h1 className="text-2xl font-semibold text-foreground mb-2 text-center">
          Create your profile
        </h1>
        <p className="text-muted-foreground text-center mb-8">
          Show off your best self
        </p>

        {/* Photo Upload */}
        <div className="flex justify-center mb-8">
          <button
            onClick={handlePhotoChange}
            className="relative w-32 h-32 rounded-full overflow-hidden group"
          >
            {photoPreview ? (
              <img
                src={photoPreview || "/placeholder.svg"}
                alt="Profile preview"
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full border-2 border-dashed border-border rounded-full flex flex-col items-center justify-center bg-muted/50 hover:bg-muted transition-colors">
                <Camera className="w-8 h-8 text-muted-foreground mb-1" />
                <span className="text-xs text-muted-foreground">Add photo</span>
              </div>
            )}
            <div className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-primary flex items-center justify-center shadow-lg">
              <Plus className="w-5 h-5 text-white" />
            </div>
          </button>
        </div>

        {/* Form Fields */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Name <span className="text-destructive">*</span>
            </label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your first name"
              className="h-12 border-border focus:border-primary focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Age <span className="text-destructive">*</span>
            </label>
            <Input
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder="Your age"
              min={18}
              max={99}
              className="h-12 border-border focus:border-primary focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Bio <span className="text-muted-foreground font-normal">(optional)</span>
            </label>
            <div className="relative">
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value.slice(0, 250))}
                placeholder="Tell others about yourself..."
                maxLength={250}
                rows={3}
                className="w-full px-4 py-3 border border-border rounded-lg resize-none text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary focus:outline-none"
              />
              <span className="absolute bottom-2 right-3 text-xs text-muted-foreground">
                {bio.length}/250
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-6 safe-bottom">
        <Button
          onClick={handleContinue}
          disabled={!isValid}
          className="w-full h-14 bg-primary hover:bg-primary-hover text-primary-foreground font-semibold text-base rounded-xl transition-all active:scale-[0.98] disabled:opacity-50"
        >
          Continue
        </Button>
      </div>
    </div>
  )
}
